weather_api_key = "a512522008a3a76c13a65066ca221994"

g_key = ""